/* Your Bot Default Prefix For Every Server */
exports.Default_Prefix = "~";
/* Your Bot All Embeds Color */
exports.Color = "7DFF27";
/* Your Bot Token (Secret) */
exports.Token = "";
/* Bot's Owner ID */
exports.OwnerID = "774886672415326238";